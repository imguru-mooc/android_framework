package com.example.hvacsimulator;

import android.car.Car;
import android.car.VehiclePropertyIds;
import android.car.hardware.CarPropertyConfig;
import android.car.hardware.CarPropertyValue;
import android.car.hardware.property.CarPropertyManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "HvacSim";
    private static final int CELSIUS = 0x30, FAHRENHEIT = 0x31;
    private final String[] fanModes = {"OFF", "LOW", "MEDIUM", "HIGH"};
    private Car car;
    private CarPropertyManager pm;
    private int areaLeft, areaRight;
    private int[] tempAreas, fanAreas, powerAreas;
    private float tempMin = 16f, tempMax = 32f;
    private float cMin = 16f, cStep = .5f, fMin = 60f, fStep = 1f;
    private int fanMin = 0, fanMax = 7;
    private float leftTemp = 22f, rightTemp = 22f;
    private int fanMode;
    private boolean useCelsius = true;
    private TextView status, leftDisplay, rightDisplay, fanDisplay;
    private Button fanButton, unitButton;
    private LinearLayout root;
    private ImageView fanIcon;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        root = findViewById(R.id.root_layout);
        leftDisplay = findViewById(R.id.temp_display_left);
        rightDisplay = findViewById(R.id.temp_display_right);
        fanDisplay = findViewById(R.id.fan_display);
        fanButton = findViewById(R.id.fan_button);
        unitButton = findViewById(R.id.unit_toggle_button);
        fanIcon = findViewById(R.id.fan_icon);
        unitButton.setOnClickListener(v -> toggleUnit());
        findViewById(R.id.temp_up_left).setOnClickListener(v -> adjustTemp(areaLeft, true));
        findViewById(R.id.temp_down_left).setOnClickListener(v -> adjustTemp(areaLeft, false));
        findViewById(R.id.temp_up_right).setOnClickListener(v -> adjustTemp(areaRight, true));
        findViewById(R.id.temp_down_right).setOnClickListener(v -> adjustTemp(areaRight, false));
        fanButton.setOnClickListener(v -> setFan((fanMode + 1) % fanModes.length));

        try {
            if (getPackageManager().hasSystemFeature("android.hardware.type.automotive")) {
                car = Car.createCar(this, null, Car.CAR_WAIT_TIMEOUT_WAIT_FOREVER, (c, ready) -> {
                    if (!ready) {
                        pm = null;
                        runOnUiThread(() -> status.setText("CarService 연결 끊김"));
                        return;
                    }
                    pm = (CarPropertyManager) c.getCarManager(Car.PROPERTY_SERVICE);
                    runOnUiThread(this::initFromCar);
                });
            } else status.setText("시뮬레이터 모드");
        } catch (NoClassDefFoundError | Exception e) {
            Log.w(TAG, "Car API unavailable", e);
            status.setText("Car API 미지원");
        }
        updateDisplays();
    }

    private void initFromCar() {
        try {
            CarPropertyConfig<?> tc = pm.getCarPropertyConfig(VehiclePropertyIds.HVAC_TEMPERATURE_SET);
            if (tc == null) throw new IllegalStateException("HVAC_TEMPERATURE_SET 미지원");
            tempAreas = tc.getAreaIds();
            if (tempAreas == null || tempAreas.length == 0) throw new IllegalStateException("온도 Area 없음");

            // AAOS commonly uses combined masks (e.g. 49/68), so 1/4 must not be hard-coded.
            areaLeft = areaWithSeat(tempAreas, 0x1, tempAreas[0]);
            areaRight = areaWithSeat(tempAreas, 0x4, tempAreas.length > 1 ? tempAreas[1] : areaLeft);
            Object min = tc.getMinValue(areaLeft), max = tc.getMaxValue(areaLeft);
            if (min instanceof Float) tempMin = (Float) min;
            if (max instanceof Float) tempMax = (Float) max;
            readTemperatureMapping(tc);
            leftTemp = readFloat(VehiclePropertyIds.HVAC_TEMPERATURE_SET, areaLeft, leftTemp);
            rightTemp = readFloat(VehiclePropertyIds.HVAC_TEMPERATURE_SET, areaRight, rightTemp);

            CarPropertyConfig<?> fc = pm.getCarPropertyConfig(VehiclePropertyIds.HVAC_FAN_SPEED);
            if (fc != null) {
                fanAreas = fc.getAreaIds();
                if (fanAreas != null && fanAreas.length > 0) {
                    Object lo = fc.getMinValue(fanAreas[0]), hi = fc.getMaxValue(fanAreas[0]);
                    if (lo instanceof Integer) fanMin = (Integer) lo;
                    if (hi instanceof Integer) fanMax = (Integer) hi;
                    fanMode = speedToMode(readInt(VehiclePropertyIds.HVAC_FAN_SPEED, fanAreas[0], 0));
                    pm.subscribePropertyEvents(VehiclePropertyIds.HVAC_FAN_SPEED, callback);
                }
            }
            CarPropertyConfig<?> pc = pm.getCarPropertyConfig(VehiclePropertyIds.HVAC_POWER_ON);
            if (pc != null) powerAreas = pc.getAreaIds();
            pm.subscribePropertyEvents(VehiclePropertyIds.HVAC_TEMPERATURE_SET, callback);
            try {
                pm.subscribePropertyEvents(VehiclePropertyIds.HVAC_TEMPERATURE_DISPLAY_UNITS, callback);
                useCelsius = readInt(VehiclePropertyIds.HVAC_TEMPERATURE_DISPLAY_UNITS, 0, CELSIUS) == CELSIUS;
            } catch (Exception e) { Log.w(TAG, "Display unit unsupported", e); }

            status.setText("연결됨 · 온도 Area " + areaLeft + "/" + areaRight + " · 팬 " + fanMin + "~" + fanMax);
            Log.i(TAG, "tempAreas=" + Arrays.toString(tempAreas) + " fanAreas=" + Arrays.toString(fanAreas));
        } catch (Exception e) {
            status.setText("초기화 실패: " + e.getMessage());
            Log.e(TAG, "init failed", e);
        }
        updateDisplays();
    }

    private void readTemperatureMapping(CarPropertyConfig<?> config) {
        List<Integer> a = config.getConfigArray();
        // [C min*10, C max*10, C step*10, F min*10, F max*10, F step*10]
        if (a != null && a.size() >= 6 && a.get(2) > 0 && a.get(5) > 0) {
            cMin = a.get(0) / 10f; cStep = a.get(2) / 10f;
            fMin = a.get(3) / 10f; fStep = a.get(5) / 10f;
            Log.i(TAG, "temperature configArray=" + a);
        } else {
            cMin = tempMin; cStep = .5f;
            fMin = cMin * 9f / 5f + 32f; fStep = cStep * 9f / 5f;
        }
    }

    private final CarPropertyManager.CarPropertyEventCallback callback = new CarPropertyManager.CarPropertyEventCallback() {
        @Override public void onChangeEvent(CarPropertyValue value) {
            int id = value.getPropertyId();
            if (id == VehiclePropertyIds.HVAC_TEMPERATURE_SET) {
                if (value.getAreaId() == areaLeft) leftTemp = (Float) value.getValue();
                if (value.getAreaId() == areaRight) rightTemp = (Float) value.getValue();
            } else if (id == VehiclePropertyIds.HVAC_FAN_SPEED) {
                fanMode = speedToMode((Integer) value.getValue());
            } else if (id == VehiclePropertyIds.HVAC_TEMPERATURE_DISPLAY_UNITS) {
                useCelsius = ((Integer) value.getValue()) == CELSIUS;
            }
            runOnUiThread(MainActivity.this::updateDisplays);
        }
        @Override public void onErrorEvent(int id, int area) {
            Log.e(TAG, "property error 0x" + Integer.toHexString(id) + " area=" + area);
        }
    };

    private void toggleUnit() {
        boolean next = !useCelsius;
        if (pm != null) {
            try {
                pm.setProperty(Integer.class, VehiclePropertyIds.HVAC_TEMPERATURE_DISPLAY_UNITS, 0, next ? CELSIUS : FAHRENHEIT);
            } catch (Exception e) {
                status.setText("단위 변경 실패: " + e.getMessage());
                return;
            }
        }
        useCelsius = next;
        updateDisplays();
    }

    private void adjustTemp(int area, boolean up) {
        float current = area == areaLeft ? leftTemp : rightTemp;
        setTemp(area, current + (up ? cStep : -cStep));
    }

    private void setTemp(int area, float requested) {
        float value = cMin + Math.round((requested - cMin) / cStep) * cStep;
        if (value < tempMin || value > tempMax) {
            status.setText(String.format("범위 밖: %.1f (%.1f~%.1f)", value, tempMin, tempMax));
            return;
        }
        if (area == areaLeft) leftTemp = value;
        if (area == areaRight) rightTemp = value;
        updateDisplays();
        if (pm == null) return;
        try {
            pm.setProperty(Float.class, VehiclePropertyIds.HVAC_TEMPERATURE_SET, area, value);
            status.setText("온도 설정: " + formatTemp(value));
        } catch (Exception e) {
            status.setText("온도 설정 실패: " + e.getMessage());
            Log.e(TAG, "temperature write failed", e);
        }
    }

    private void setFan(int mode) {
        fanMode = mode;
        updateDisplays();
        if (pm == null) return;
        int speed = modeToSpeed(mode);
        if (mode > 0) writePowerBestEffort(true);
        fanButton.postDelayed(() -> {
            try {
                writeFanSpeed(speed);
                status.setText("팬 모드: " + fanModes[mode] + " (VHAL " + speed + ")");
                if (mode == 0) writePowerBestEffort(false);
            } catch (Exception e) {
                status.setText("팬 설정 실패: " + e.getMessage());
                Log.e(TAG, "fan write failed", e);
            }
        }, mode > 0 ? 150L : 0L);
    }

    private int modeToSpeed(int mode) {
        if (mode == 0) return 0;
        int low = Math.max(1, fanMin);
        if (mode == 1) return low;
        if (mode == 3) return fanMax;
        return Math.round((low + fanMax) / 2f);
    }

    private int speedToMode(int speed) {
        if (speed <= 0) return 0;
        int low = modeToSpeed(1), mid = modeToSpeed(2), high = modeToSpeed(3);
        if (speed < (low + mid) / 2f) return 1;
        if (speed < (mid + high) / 2f) return 2;
        return 3;
    }

    private void writeFanSpeed(int speed) {
        if (fanAreas == null || fanAreas.length == 0) throw new IllegalStateException("HVAC_FAN_SPEED 미지원");
        int successes = 0;
        Exception last = null;
        for (int area : fanAreas) {
            try {
                pm.setProperty(Integer.class, VehiclePropertyIds.HVAC_FAN_SPEED, area, speed);
                successes++;
            } catch (Exception e) { last = e; Log.w(TAG, "fan area failed=" + area, e); }
        }
        if (successes == 0) throw new IllegalStateException(last == null ? "팬 속도 쓰기 실패" : last.getMessage(), last);
    }

    private void writePowerBestEffort(boolean on) {
        if (powerAreas == null) return;
        for (int area : powerAreas) {
            try { pm.setProperty(Boolean.class, VehiclePropertyIds.HVAC_POWER_ON, area, on); }
            catch (Exception e) { Log.w(TAG, "power area skipped=" + area, e); }
        }
    }

    private float readFloat(int id, int area, float fallback) {
        try {
            CarPropertyValue<Float> v = pm.getProperty(Float.class, id, area);
            return v == null ? fallback : v.getValue();
        } catch (Exception e) { return fallback; }
    }

    private int readInt(int id, int area, int fallback) {
        try {
            CarPropertyValue<Integer> v = pm.getProperty(Integer.class, id, area);
            return v == null ? fallback : v.getValue();
        } catch (Exception e) { return fallback; }
    }

    private int areaWithSeat(int[] areas, int bit, int fallback) {
        for (int area : areas) if ((area & bit) != 0) return area;
        return fallback;
    }

    private void updateDisplays() {
        leftDisplay.setText(formatTemp(leftTemp));
        rightDisplay.setText(formatTemp(rightTemp));
        leftDisplay.setTextColor(tempColor(leftTemp));
        rightDisplay.setTextColor(tempColor(rightTemp));
        fanDisplay.setText("FAN: " + fanModes[fanMode]);
        unitButton.setText(useCelsius ? "단위: °C" : "단위: °F");
        root.setBackgroundColor(Color.parseColor(leftTemp >= 26 || rightTemp >= 26 ? "#FF5722" : leftTemp <= 18 || rightTemp <= 18 ? "#2196F3" : "#202124"));
        if (fanMode == 0) fanIcon.clearAnimation();
        else {
            Animation a = AnimationUtils.loadAnimation(this, R.anim.rotate_fan);
            a.setDuration(2000L / fanMode);
            fanIcon.startAnimation(a);
        }
    }

    private int tempColor(float c) { return c >= 26 ? Color.RED : c <= 18 ? Color.CYAN : Color.WHITE; }

    private String formatTemp(float c) {
        if (useCelsius) return String.format("%.1f°C", c);
        int index = Math.round((c - cMin) / cStep);
        float f = fMin + index * fStep;
        return Math.abs(f - Math.round(f)) < .001f ? String.format("%d°F", Math.round(f)) : String.format("%.1f°F", f);
    }

    @Override protected void onDestroy() {
        if (pm != null) pm.unsubscribePropertyEvents(callback);
        if (car != null) car.disconnect();
        super.onDestroy();
    }
}
